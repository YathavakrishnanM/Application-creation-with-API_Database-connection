"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
function addUser(user) {
    return __awaiter(this, void 0, void 0, function* () {
        const response = yield fetch('http://localhost:5166/api/Users', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(user)
        });
        if (!response.ok) {
            throw new Error("Field to add user");
        }
    });
}
function fetchUser() {
    return __awaiter(this, void 0, void 0, function* () {
        const response = yield fetch('http://localhost:5166/api/Users');
        if (!response.ok) {
            throw new Error('Faild to fetch User');
        }
        return yield response.json();
    });
}
function updateUser(userID, user) {
    return __awaiter(this, void 0, void 0, function* () {
        const response = yield fetch(`http://localhost:5166/api/Users/${userID}`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(user)
        });
        if (!response.ok) {
            throw new Error('Faild to update user');
        }
    });
}
function deleteUser(userID) {
    return __awaiter(this, void 0, void 0, function* () {
        const response = yield fetch(`http://localhost:5166/api/Users/${userID}`, {
            method: 'DELETE',
        });
        if (!response) {
            throw new Error('Faild to delete user');
        }
    });
}
function addOrder(order) {
    return __awaiter(this, void 0, void 0, function* () {
        const response = yield fetch('http://localhost:5166/api/OrderDetails', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(order)
        });
        if (!response.ok) {
            throw new Error("Field to add order");
        }
    });
}
function fetchOrder() {
    return __awaiter(this, void 0, void 0, function* () {
        const response = yield fetch('http://localhost:5166/api/OrderDetails');
        if (!response.ok) {
            throw new Error('Faild to fetch order');
        }
        return yield response.json();
    });
}
function updateOrder(orderID, order) {
    return __awaiter(this, void 0, void 0, function* () {
        const response = yield fetch(`http://localhost:5166/api/OrderDetails/${orderID}`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(order)
        });
        if (!response.ok) {
            throw new Error('Faild to update order');
        }
    });
}
function deleteOrder(orderID) {
    return __awaiter(this, void 0, void 0, function* () {
        const response = yield fetch(`http://localhost:5166/api/OrderDetails/${orderID}`, {
            method: 'DELETE',
        });
        if (!response) {
            throw new Error('Faild to delete order');
        }
    });
}
function addGrocery(grocery) {
    return __awaiter(this, void 0, void 0, function* () {
        const response = yield fetch('http://localhost:5166/api/GroceryDetails', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(grocery)
        });
        if (!response.ok) {
            throw new Error("Field to add grocery");
        }
    });
}
function fetchGrocery() {
    return __awaiter(this, void 0, void 0, function* () {
        const response = yield fetch('http://localhost:5166/api/GroceryDetails');
        if (!response.ok) {
            throw new Error('Faild to fetch grocery');
        }
        return yield response.json();
    });
}
function updateGrocery(groceryID, grocery) {
    return __awaiter(this, void 0, void 0, function* () {
        const response = yield fetch(`http://localhost:5166/api/GroceryDetails/${groceryID}`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(grocery)
        });
        if (!response.ok) {
            throw new Error('Faild to update grocery');
        }
    });
}
function deleteGrocery(groceryID) {
    return __awaiter(this, void 0, void 0, function* () {
        const response = yield fetch(`http://localhost:5166/api/GroceryDetails/${groceryID}`, {
            method: 'DELETE',
        });
        if (!response) {
            throw new Error('Faild to delete grocey');
        }
    });
}
function addbill(b) {
    return __awaiter(this, void 0, void 0, function* () {
        const response = yield fetch('http://localhost:5166/api/Bill', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(b)
        });
        if (!response.ok) {
            throw new Error("Field to add bill");
        }
    });
}
function fetchBill() {
    return __awaiter(this, void 0, void 0, function* () {
        const response = yield fetch('http://localhost:5166/api/Bill');
        if (!response.ok) {
            throw new Error('Faild to fetch bill');
        }
        return yield response.json();
    });
}
function updateBill(billid, bill) {
    return __awaiter(this, void 0, void 0, function* () {
        const response = yield fetch(`http://localhost:5166/api/Bill/${billid}`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(bill)
        });
        if (!response.ok) {
            throw new Error('Faild to update bill');
        }
    });
}
function toRegisterPage() {
    document.getElementById("main_page").style.display = "none";
    document.getElementById("register_Page").style.display = "block";
    document.getElementById("login_page").style.display = "none";
}
function registration() {
    var _a;
    let email = document.getElementById("email");
    let username = document.getElementById("username");
    let password = document.getElementById("password");
    let balance = document.getElementById("balance");
    let phoneNumber = document.getElementById("phoneNumber");
    let photo = document.getElementById("photo");
    let address = document.getElementById("address");
    // change string to base64string
    try {
        const file = (_a = photo.files) === null || _a === void 0 ? void 0 : _a[0];
        const reader = new FileReader();
        reader.readAsDataURL(file);
        reader.onload = function (event) {
            var _a;
            var base64String = (_a = event.target) === null || _a === void 0 ? void 0 : _a.result;
            if (email.value != "" && password.value != "" && balance.value != "" && phoneNumber.value != "" && address.value != "" && photo.value != "" && username.value != "") {
                let newUser = {
                    userID: undefined,
                    emailID: email.value,
                    password: password.value,
                    walletBalance: Number(balance.value),
                    phoneNumber: phoneNumber.value,
                    address: address.value,
                    userPhoto: [base64String],
                    userName: username.value
                };
                addUser(newUser);
                alert("Registration success!");
                toLoginPage();
            }
            else {
                alert("Please fill all fields");
            }
        };
    }
    catch (_b) {
        alert("Please fill all fields");
    }
}
function toLoginPage() {
    let login_page = document.getElementById("login_page");
    document.getElementById("main_page").style.display = "none";
    document.getElementById("register_Page").style.display = "none";
    login_page.style.display = "block";
}
var tempUserStore;
var flag = false;
function login() {
    return __awaiter(this, void 0, void 0, function* () {
        let user_enter_email = document.getElementById("user_enter_email");
        let user_enster_password = document.getElementById("user_enster_password");
        let users = yield fetchUser();
        if (user_enter_email.value != "" && user_enster_password.value != "") {
            users.forEach(user => {
                if (user_enter_email.value == user.emailID && user_enster_password.value == user.password) {
                    flag = true;
                    tempUserStore = user;
                    return;
                }
            });
        }
        if (flag) {
            user_enter_email.value = "";
            user_enster_password.value = "";
            flag = false;
            userPage();
        }
        else {
            alert("Invalid Email or Password!");
        }
    });
}
function userPage() {
    document.getElementById("inside_mainpage").style.display = "block";
    document.getElementById("main_page").style.display = "none";
    document.getElementById("register_Page").style.display = "none";
    document.getElementById("login_page").style.display = "none";
}
function homepage() {
    return __awaiter(this, void 0, void 0, function* () {
        document.getElementById("home_content").style.display = "block";
        document.getElementById("WalletBalance_content").style.display = "none";
        document.getElementById("Walletrecharge_content").style.display = "none";
        document.getElementById("Purchase_content").style.display = "none";
        document.getElementById("Addproduct_content").style.display = "none";
        document.getElementById("Grocery_items_content").style.display = "none";
        document.getElementById("Card_content").style.display = "none";
        document.getElementById("View_order_history_content").style.display = "none";
        document.getElementById("SignOut").style.display = "none";
        document.getElementById("askcount_page").style.display = "none";
        let home_content = document.getElementById("home_content");
        let users = yield fetchUser();
        home_content.innerHTML = "";
        users.forEach(user => {
            if (tempUserStore.userID == user.userID) {
                home_content.innerHTML = `<h1>Welcome ${user.userName} </h1><img src="${user.userPhoto}" height=50px width=50px>`;
            }
        });
    });
}
function walletbalancepage() {
    return __awaiter(this, void 0, void 0, function* () {
        document.getElementById("home_content").style.display = "none";
        document.getElementById("WalletBalance_content").style.display = "block";
        document.getElementById("Walletrecharge_content").style.display = "none";
        document.getElementById("Purchase_content").style.display = "none";
        document.getElementById("Addproduct_content").style.display = "none";
        document.getElementById("Grocery_items_content").style.display = "none";
        document.getElementById("Card_content").style.display = "none";
        document.getElementById("View_order_history_content").style.display = "none";
        document.getElementById("SignOut").style.display = "none";
        document.getElementById("askcount_page").style.display = "none";
        let WalletBalance_content = document.getElementById("WalletBalance_content");
        let users = yield fetchUser();
        WalletBalance_content.innerHTML = "";
        users.forEach(user => {
            if (tempUserStore.userID == user.userID) {
                WalletBalance_content.innerHTML = `<h1>your current balance is  ${user.walletBalance} </h1>`;
            }
        });
    });
}
function walletrechargepage() {
    document.getElementById("home_content").style.display = "none";
    document.getElementById("WalletBalance_content").style.display = "none";
    document.getElementById("Walletrecharge_content").style.display = "block";
    document.getElementById("Purchase_content").style.display = "none";
    document.getElementById("Addproduct_content").style.display = "none";
    document.getElementById("Grocery_items_content").style.display = "none";
    document.getElementById("Card_content").style.display = "none";
    document.getElementById("View_order_history_content").style.display = "none";
    document.getElementById("SignOut").style.display = "none";
    document.getElementById("askcount_page").style.display = "none";
}
function conformRecharge() {
    return __awaiter(this, void 0, void 0, function* () {
        let amount = document.getElementById("amount");
        let users = yield fetchUser();
        if (amount.value != "") {
            users.forEach(user => {
                if (tempUserStore.userID == user.userID) {
                    let userUpdate = {
                        userID: user.userID,
                        emailID: user.emailID,
                        password: user.password,
                        walletBalance: Number(user.walletBalance) + Number(amount.value),
                        phoneNumber: user.phoneNumber,
                        address: user.address,
                        userPhoto: user.userPhoto,
                        userName: user.userName
                    };
                    updateUser(tempUserStore.userID, userUpdate);
                    amount.value = "";
                    alert("Recharge success!");
                }
            });
        }
        else {
            alert("Please enter the amount!");
        }
    });
}
function purchase() {
    return __awaiter(this, void 0, void 0, function* () {
        document.getElementById("home_content").style.display = "none";
        document.getElementById("WalletBalance_content").style.display = "none";
        document.getElementById("Walletrecharge_content").style.display = "none";
        document.getElementById("Purchase_content").style.display = "block";
        document.getElementById("Addproduct_content").style.display = "none";
        document.getElementById("Grocery_items_content").style.display = "none";
        document.getElementById("Card_content").style.display = "none";
        document.getElementById("View_order_history_content").style.display = "none";
        document.getElementById("SignOut").style.display = "none";
        document.getElementById("askcount_page").style.display = "none";
        let purchase_items = document.getElementById("purchase_items");
        purchase_items.innerHTML = "";
        let newBill = {
            billID: undefined,
            userID: tempUserStore.userID,
            totalPrice: 0,
        };
        addbill(newBill);
        let grocerys = yield fetchGrocery();
        grocerys.forEach(g => {
            purchase_items.innerHTML += `
                                <div id="card">
                                <img src="${g.itemPhoto}" alt="pic" width="60px" height="60px">
                                <h3>Name : ${g.itemName}</h3>
                                <h3>Price : ${g.price}</h3>
                                <h3> Quantity :${g.quantity}</h3>
                                <button onclick="itemaddtocard('${g.groceryID}')">Addto card</button>
                            </div>`;
        });
    });
}
var tempOrderList = new Array;
var tempIdstore;
function itemaddtocard(selectid) {
    return __awaiter(this, void 0, void 0, function* () {
        document.getElementById("home_content").style.display = "none";
        document.getElementById("WalletBalance_content").style.display = "none";
        document.getElementById("Walletrecharge_content").style.display = "none";
        document.getElementById("Purchase_content").style.display = "none";
        document.getElementById("Addproduct_content").style.display = "none";
        document.getElementById("Grocery_items_content").style.display = "none";
        document.getElementById("Card_content").style.display = "none";
        document.getElementById("View_order_history_content").style.display = "none";
        document.getElementById("SignOut").style.display = "none";
        let askcount_page = document.getElementById("askcount_page");
        askcount_page.style.display = "block";
        tempIdstore = selectid;
    });
}
var tempBillId;
function conformAddToCard() {
    return __awaiter(this, void 0, void 0, function* () {
        let count = document.getElementById("count");
        let grocery = yield fetchGrocery();
        let users = yield fetchUser();
        let bills = yield fetchBill();
        users.forEach(user => {
            if (tempUserStore.userID == user.userID) {
                tempUserStore = user;
            }
        });
        bills.forEach(bill => {
            if (tempUserStore.userID == bill.userID) {
                tempBillId = bill.billID;
            }
        });
        grocery.forEach(g => {
            if (tempIdstore == g.groceryID) {
                if (Number(g.quantity) >= Number(count.value)) {
                    if (tempUserStore.walletBalance >= g.price) {
                        let newcard = {
                            orderID: undefined,
                            orderDate: String(new Date),
                            emailID: tempUserStore.emailID,
                            itemName: g.itemName,
                            totalPrice: Number(count.value) * Number(g.price),
                            billID: tempBillId
                        };
                        tempOrderList.push(newcard);
                        let userUpdate = {
                            userID: tempUserStore.userID,
                            emailID: tempUserStore.emailID,
                            password: tempUserStore.password,
                            walletBalance: Number(tempUserStore.walletBalance) - Number(newcard.totalPrice),
                            phoneNumber: tempUserStore.phoneNumber,
                            address: tempUserStore.address,
                            userPhoto: tempUserStore.userPhoto,
                            userName: tempUserStore.userName
                        };
                        updateUser(tempUserStore.userID, userUpdate);
                        let groceryUpdate = {
                            groceryID: g.groceryID,
                            quantity: Number(g.quantity) - Number(count.value),
                            price: g.price,
                            purchaseDate: g.purchaseDate,
                            exparyDate: g.exparyDate,
                            itemPhoto: g.itemPhoto,
                            itemName: g.itemName
                        };
                        updateGrocery(g.groceryID, groceryUpdate);
                        (alert("Item added to card"));
                        count.value = "";
                        purchase();
                    }
                    else {
                        alert("Balance not available");
                        count.value = "";
                        purchase();
                    }
                }
                else {
                    alert("count available");
                    count.value = "";
                    purchase();
                }
            }
        });
    });
}
function addproductpage() {
    document.getElementById("home_content").style.display = "none";
    document.getElementById("WalletBalance_content").style.display = "none";
    document.getElementById("Walletrecharge_content").style.display = "none";
    document.getElementById("Purchase_content").style.display = "none";
    document.getElementById("Addproduct_content").style.display = "block";
    document.getElementById("Grocery_items_content").style.display = "none";
    document.getElementById("Card_content").style.display = "none";
    document.getElementById("View_order_history_content").style.display = "none";
    document.getElementById("SignOut").style.display = "none";
    document.getElementById("askcount_page").style.display = "none";
}
function grocerypage() {
    return __awaiter(this, void 0, void 0, function* () {
        document.getElementById("home_content").style.display = "none";
        document.getElementById("WalletBalance_content").style.display = "none";
        document.getElementById("Walletrecharge_content").style.display = "none";
        document.getElementById("Purchase_content").style.display = "none";
        document.getElementById("Addproduct_content").style.display = "none";
        document.getElementById("Grocery_items_content").style.display = "block";
        document.getElementById("Card_content").style.display = "none";
        document.getElementById("View_order_history_content").style.display = "none";
        document.getElementById("SignOut").style.display = "none";
        document.getElementById("askcount_page").style.display = "none";
        let grocerytable = document.getElementById("grocerytable");
        grocerytable.innerHTML = "";
        grocerytable.innerHTML = `<tr>
                                <td>${"ItemName"}</td>
                                <td>${"Quantity"}</td>
                                <td>${"Price"}</td>
                                <td>${"Purchase Date"}</td>
                                <td>${"Expary date"}</td>
                                <td>${"Picture"}</td>
                            </tr>`;
        let grocerys = yield fetchGrocery();
        grocerys.forEach(g => {
            grocerytable.innerHTML += `
                            <tr>
                                <td>${g.itemName}</td>
                                <td>${g.quantity}</td>
                                <td>${g.price}</td>
                                <td>${g.purchaseDate}</td>
                                <td>${g.exparyDate}</td>
                                <td><img src="${g.itemPhoto}" height=50px width=50px></td>
                                <td><button>edit</button>
                                <button>delete</button></td>
                            </tr>`;
        });
    });
}
function cardPage() {
    document.getElementById("home_content").style.display = "none";
    document.getElementById("WalletBalance_content").style.display = "none";
    document.getElementById("Walletrecharge_content").style.display = "none";
    document.getElementById("Purchase_content").style.display = "none";
    document.getElementById("Addproduct_content").style.display = "none";
    document.getElementById("Grocery_items_content").style.display = "none";
    document.getElementById("Card_content").style.display = "block";
    document.getElementById("View_order_history_content").style.display = "none";
    document.getElementById("SignOut").style.display = "none";
    document.getElementById("askcount_page").style.display = "none";
    let card_table = document.getElementById("card_table");
    if (tempOrderList.length > 0) {
        card_table.innerHTML = "";
        card_table.innerHTML = `<tr>
                                            <td>${"OrderDate"}</td>
                                            <td>${"EmailID"}</td>
                                            <td>${"ItemName"}</td>
                                            <td>${"Total Price"}</td>
                                            </tr>`;
        tempOrderList.forEach(g => {
            card_table.innerHTML += `
                                        <tr>
                                            <td>${g.orderDate}</td>
                                            <td>${g.emailID}</td>
                                            <td>${g.itemName}</td>
                                            <td>${g.totalPrice}</td>
                                            </tr>`;
        });
    }
    else {
        document.getElementById("Card_content").innerHTML = "<h1>No card items</h1>";
    }
}
function conform_order() {
    return __awaiter(this, void 0, void 0, function* () {
        var totalCost = 0;
        tempOrderList.forEach(order => {
            totalCost += Number(order.totalPrice);
        });
        let bills = yield fetchBill();
        let tempBill = bills[bills.length - 1];
        let billUpdate = {
            billID: tempBill.billID,
            userID: tempBill.userID,
            totalPrice: totalCost
        };
        updateBill(tempBill.billID, billUpdate);
        tempOrderList.forEach(order => {
            let newOrder = {
                orderID: order.orderID,
                billID: order.billID,
                orderDate: order.orderDate,
                emailID: order.emailID,
                itemName: order.itemName,
                totalPrice: order.totalPrice
            };
            addOrder(newOrder);
        });
        alert("OrderConformed!");
    });
}
function orderHistorypage() {
    return __awaiter(this, void 0, void 0, function* () {
        document.getElementById("home_content").style.display = "none";
        document.getElementById("WalletBalance_content").style.display = "none";
        document.getElementById("Walletrecharge_content").style.display = "none";
        document.getElementById("Purchase_content").style.display = "none";
        document.getElementById("Addproduct_content").style.display = "none";
        document.getElementById("Grocery_items_content").style.display = "none";
        document.getElementById("Card_content").style.display = "none";
        document.getElementById("View_order_history_content").style.display = "block";
        document.getElementById("SignOut").style.display = "none";
        document.getElementById("askcount_page").style.display = "none";
        let Bill_ID = document.getElementById("Bill_ID");
        let order_history_table = document.getElementById("order_history_table");
        order_history_table.innerHTML = '';
        let bills = yield fetchBill();
        let orders = yield fetchOrder();
        for (let i = 0; i < bills.length - 1; i++) {
            if (bills[i].userID == tempUserStore.userID) {
                Bill_ID.innerHTML = `<h3>Name : ${tempUserStore.userName}</h3>
            <h3>Bill ID : ${bills[i].billID}</h3>
            <h3>TotalCost : ${bills[i].totalPrice}</h3>`;
            }
            orders.forEach(order => {
                if (order.billID == bills[i].billID) {
                    order_history_table.innerHTML += `<tr>
                                                <td>${order.orderDate}</td>
                                                <td>${order.emailID}</td>
                                                <td>${order.itemName}</td>
                                                <td>${order.totalPrice}</td>
                                                </tr>`;
                }
            });
        }
    });
}
function signoutpage() {
    // (document.getElementById("home_content") as HTMLDivElement).style.display="none";
    // (document.getElementById("WalletBalance_content") as HTMLDivElement).style.display="none";
    // (document.getElementById("Walletrecharge_content") as HTMLInputElement).style.display="none";
    // (document.getElementById("Purchase_content") as HTMLInputElement).style.display="none";
    // (document.getElementById("Addproduct_content") as HTMLDivElement).style.display="none";
    // (document.getElementById("Grocery_items_content") as HTMLDivElement).style.display="none";
    // (document.getElementById("Card_content") as HTMLInputElement).style.display="none";
    // (document.getElementById("View_order_history_content") as HTMLInputElement).style.display="none";
    // (document.getElementById("SignOut") as HTMLInputElement).style.display="block";
    document.getElementById("main_page").style.display = "block";
    document.getElementById("register_Page").style.display = "none";
    document.getElementById("login_page").style.display = "none";
}
function addproduct() {
    var _a;
    let itemname = document.getElementById("itemname");
    let quantity = document.getElementById("quantity");
    let price = document.getElementById("price");
    let purchaseDate = document.getElementById("purchaseDate");
    let exparyDate = document.getElementById("exparyDate");
    let itemPhoto = document.getElementById("itemPhoto");
    try {
        const file = (_a = itemPhoto.files) === null || _a === void 0 ? void 0 : _a[0];
        const reader = new FileReader();
        reader.readAsDataURL(file);
        reader.onload = function (event) {
            var _a;
            var base64String = (_a = event.target) === null || _a === void 0 ? void 0 : _a.result;
            if (itemname.value != "" && quantity.value != "" && price.value != "" && purchaseDate.value != "" && exparyDate.value != "") {
                let newGrocery = {
                    groceryID: undefined,
                    quantity: Number(quantity.value),
                    price: Number(price.value),
                    purchaseDate: purchaseDate.value,
                    exparyDate: exparyDate.value,
                    itemPhoto: [base64String],
                    itemName: itemname.value
                };
                addGrocery(newGrocery);
                itemname.value != "";
                quantity.value != "";
                price.value != "";
                purchaseDate.value != "";
                exparyDate.value != "";
                addproduct();
                alert("Item added success!");
            }
            else {
                alert("Please fill all fields");
            }
        };
    }
    catch (_b) {
        alert("Please fill all fields");
    }
}

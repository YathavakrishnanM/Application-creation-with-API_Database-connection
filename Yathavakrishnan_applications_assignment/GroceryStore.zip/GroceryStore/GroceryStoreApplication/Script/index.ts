interface UserDetails{
    userID:any;
    emailID:string;
    password:string;
    walletBalance:Number;
    phoneNumber:string;
    address:string;
    userPhoto:string[];
    userName:string;
}

async function addUser(user:UserDetails) {
    const response=await fetch('http://localhost:5166/api/Users',{
        method:'POST',
        headers:{
            'Content-Type' : 'application/json'
        },
        body:JSON.stringify(user)
    });

    if(!response.ok){
        throw new Error("Field to add user");
    }
}

async function fetchUser():Promise<UserDetails[]> {
    const response=await fetch('http://localhost:5166/api/Users')
    if(!response.ok){
        throw new Error('Faild to fetch User')
    }
    return await response.json();
}

async function updateUser(userID:number,user :UserDetails) : Promise<void>{
    const response=await fetch(`http://localhost:5166/api/Users/${userID}`,{
        method:'PUT',
        headers:{
            'Content-Type' : 'application/json'
        },
        body:JSON.stringify(user)
    });
    if(!response.ok){
        throw new Error('Faild to update user');
    }
}

async function deleteUser(userID:any) {
    const response=await fetch(`http://localhost:5166/api/Users/${userID}`,{
        method:'DELETE',
        });
        if(!response){
            throw new Error('Faild to delete user');
        }
}



interface OrderDetails{
        orderID:any;
        billID:number;
        orderDate:string;
        emailID:string;
        itemName:string;
        totalPrice:Number;
}
async function addOrder(order:OrderDetails) {
    const response=await fetch('http://localhost:5166/api/OrderDetails',{
        method:'POST',
        headers:{
            'Content-Type' : 'application/json'
        },
        body:JSON.stringify(order)
    });

    if(!response.ok){
        throw new Error("Field to add order");
    }
}

async function fetchOrder():Promise<OrderDetails[]> {
    const response=await fetch('http://localhost:5166/api/OrderDetails')
    if(!response.ok){
        throw new Error('Faild to fetch order')
    }
    return await response.json();
}

async function updateOrder(orderID:any,order :OrderDetails) : Promise<void>{
    const response=await fetch(`http://localhost:5166/api/OrderDetails/${orderID}`,{
        method:'PUT',
        headers:{
            'Content-Type' : 'application/json'
        },
        body:JSON.stringify(order)
    });
    if(!response.ok){
        throw new Error('Faild to update order');
    }
}

async function deleteOrder(orderID:any) {
    const response=await fetch(`http://localhost:5166/api/OrderDetails/${orderID}`,{
        method:'DELETE',
        });
        if(!response){
            throw new Error('Faild to delete order');
        }
}

interface GroceryDetails{
    groceryID:any;
    quantity:Number;
    price:Number;
    purchaseDate:string;
    exparyDate:string;
    itemPhoto:string[];
    itemName:string
}
async function addGrocery(grocery:GroceryDetails) {
    const response=await fetch('http://localhost:5166/api/GroceryDetails',{
        method:'POST',
        headers:{
            'Content-Type' : 'application/json'
        },
        body:JSON.stringify(grocery)
    });

    if(!response.ok){
        throw new Error("Field to add grocery");
    }
}

async function fetchGrocery():Promise<GroceryDetails[]> {
    const response=await fetch('http://localhost:5166/api/GroceryDetails')
    if(!response.ok){
        throw new Error('Faild to fetch grocery')
    }
    return await response.json();
}

async function updateGrocery(groceryID:any,grocery :GroceryDetails) : Promise<void>{
    const response=await fetch(`http://localhost:5166/api/GroceryDetails/${groceryID}`,{
        method:'PUT',
        headers:{
            'Content-Type' : 'application/json'
        },
        body:JSON.stringify(grocery)
    });
    if(!response.ok){
        throw new Error('Faild to update grocery');
    }
}

async function deleteGrocery(groceryID:any) {
    const response=await fetch(`http://localhost:5166/api/GroceryDetails/${groceryID}`,{
        method:'DELETE',
        });
        if(!response){
            throw new Error('Faild to delete grocey');
        }
}


interface Bill{
    billID:any;
    userID:Number;
    totalPrice:Number;
   }


async function addbill(b:Bill) {
    const response=await fetch('http://localhost:5166/api/Bill',{
        method:'POST',
        headers:{
            'Content-Type' : 'application/json'
        },
        body:JSON.stringify(b)
    });

    if(!response.ok){
        throw new Error("Field to add bill");
    }
}

async function fetchBill():Promise<Bill[]> {
    const response=await fetch('http://localhost:5166/api/Bill')
    if(!response.ok){
        throw new Error('Faild to fetch bill')
    }
    return await response.json();
}

async function updateBill(billid:number,bill :Bill) : Promise<void>{
    const response=await fetch(`http://localhost:5166/api/Bill/${billid}`,{
        method:'PUT',
        headers:{
            'Content-Type' : 'application/json'
        },
        body:JSON.stringify(bill)
    });
    if(!response.ok){
        throw new Error('Faild to update bill');
    }
}

function toRegisterPage(){

    (document.getElementById("main_page") as HTMLDivElement).style.display="none";
    (document.getElementById("register_Page") as HTMLInputElement).style.display="block";
    (document.getElementById("login_page") as HTMLInputElement).style.display="none";
}


function registration(){
    let email=document.getElementById("email") as HTMLInputElement;
    let username=document.getElementById("username") as HTMLInputElement;
    let password=document.getElementById("password") as HTMLInputElement;
    let balance=document.getElementById("balance") as HTMLInputElement;
    let phoneNumber=document.getElementById("phoneNumber") as HTMLInputElement;
    let photo=document.getElementById("photo") as HTMLInputElement;
    let address=document.getElementById("address") as HTMLTextAreaElement;

    

    // change string to base64string
        try{
            const file:any= photo.files?.[0];
            const reader = new FileReader();
            reader.readAsDataURL(file);
            reader.onload = function (event) {
                var base64String =  event.target?.result as string;
                
                if(email.value!="" && password.value!="" && balance.value!="" && phoneNumber.value!=""  && address.value!=""  && photo.value!="" && username.value!=""){
                        let newUser:UserDetails={
                            userID: undefined,
                            emailID: email.value,
                            password: password.value,
                            walletBalance: Number(balance.value),
                            phoneNumber: phoneNumber.value,
                            address: address.value,
                            userPhoto: [base64String],
                            userName: username.value
                        }

                        addUser(newUser);
                        alert("Registration success!");
                        toLoginPage()
                }
                else{
                    alert("Please fill all fields");
                }
            }
        }catch{
            alert("Please fill all fields")
        }
}


function toLoginPage(){

    let login_page=document.getElementById("login_page") as HTMLDivElement;
    (document.getElementById("main_page") as HTMLDivElement).style.display="none";
    (document.getElementById("register_Page") as HTMLInputElement).style.display="none";

    login_page.style.display="block";

    

    
}


var tempUserStore:UserDetails;
var flag:boolean=false;


async function login(){

    let user_enter_email=document.getElementById("user_enter_email") as HTMLInputElement;
    let user_enster_password=document.getElementById("user_enster_password") as HTMLInputElement;


    let users=await fetchUser();

    if(user_enter_email.value!="" && user_enster_password.value!=""){


        users.forEach(user=>{
                if(user_enter_email.value == user.emailID  &&  user_enster_password.value == user.password){
                    flag=true;
                    tempUserStore=user;
                    return;
                }
        });
    }

    if(flag){
        user_enter_email.value="";
        user_enster_password.value="";
        flag=false;
        userPage();

    }else{
        alert("Invalid Email or Password!");
    }    
}


function userPage(){
    (document.getElementById("inside_mainpage") as HTMLDivElement).style.display="block";
    (document.getElementById("main_page") as HTMLDivElement).style.display="none";
    (document.getElementById("register_Page") as HTMLInputElement).style.display="none";
    (document.getElementById("login_page") as HTMLInputElement).style.display="none";
}


async function homepage(){
    (document.getElementById("home_content") as HTMLDivElement).style.display="block";
    (document.getElementById("WalletBalance_content") as HTMLDivElement).style.display="none";
    (document.getElementById("Walletrecharge_content") as HTMLInputElement).style.display="none";
    (document.getElementById("Purchase_content") as HTMLInputElement).style.display="none";
    (document.getElementById("Addproduct_content") as HTMLDivElement).style.display="none";
    (document.getElementById("Grocery_items_content") as HTMLDivElement).style.display="none";
    (document.getElementById("Card_content") as HTMLInputElement).style.display="none";
    (document.getElementById("View_order_history_content") as HTMLInputElement).style.display="none";
    (document.getElementById("SignOut") as HTMLInputElement).style.display="none";
    (document.getElementById("askcount_page") as HTMLInputElement).style.display="none";


    let home_content=document.getElementById("home_content") as HTMLDivElement;

    let users=await fetchUser();
    home_content.innerHTML="";
    users.forEach(user=>{
        if(tempUserStore.userID==user.userID){
            home_content.innerHTML=`<h1>Welcome ${user.userName} </h1><img src="${user.userPhoto}" height=50px width=50px>`
        }
    })


}

async function walletbalancepage(){
    (document.getElementById("home_content") as HTMLDivElement).style.display="none";
    (document.getElementById("WalletBalance_content") as HTMLDivElement).style.display="block";
    (document.getElementById("Walletrecharge_content") as HTMLInputElement).style.display="none";
    (document.getElementById("Purchase_content") as HTMLInputElement).style.display="none";
    (document.getElementById("Addproduct_content") as HTMLDivElement).style.display="none";
    (document.getElementById("Grocery_items_content") as HTMLDivElement).style.display="none";
    (document.getElementById("Card_content") as HTMLInputElement).style.display="none";
    (document.getElementById("View_order_history_content") as HTMLInputElement).style.display="none";
    (document.getElementById("SignOut") as HTMLInputElement).style.display="none";
    (document.getElementById("askcount_page") as HTMLInputElement).style.display="none";

    let WalletBalance_content=document.getElementById("WalletBalance_content") as HTMLDivElement;
    
        let users=await fetchUser();
        WalletBalance_content.innerHTML="";
        users.forEach(user=>{
            if(tempUserStore.userID==user.userID){
                WalletBalance_content.innerHTML=`<h1>your current balance is  ${user.walletBalance} </h1>`
            }
        })
}


function walletrechargepage(){
    (document.getElementById("home_content") as HTMLDivElement).style.display="none";
    (document.getElementById("WalletBalance_content") as HTMLDivElement).style.display="none";
    (document.getElementById("Walletrecharge_content") as HTMLInputElement).style.display="block";
    (document.getElementById("Purchase_content") as HTMLInputElement).style.display="none";
    (document.getElementById("Addproduct_content") as HTMLDivElement).style.display="none";
    (document.getElementById("Grocery_items_content") as HTMLDivElement).style.display="none";
    (document.getElementById("Card_content") as HTMLInputElement).style.display="none";
    (document.getElementById("View_order_history_content") as HTMLInputElement).style.display="none";
    (document.getElementById("SignOut") as HTMLInputElement).style.display="none";
    (document.getElementById("askcount_page") as HTMLInputElement).style.display="none";
}

async function conformRecharge(){

    let amount=document.getElementById("amount") as HTMLInputElement;
    let users=await fetchUser();
    if(amount.value!=""){

        users.forEach(user=>{
            if(tempUserStore.userID==user.userID){
                let  userUpdate:UserDetails={
                    userID: user.userID,
                    emailID:user.emailID,
                    password: user.password,
                    walletBalance:Number(user.walletBalance) + Number(amount.value),
                    phoneNumber: user.phoneNumber,
                    address: user.address,
                    userPhoto:user.userPhoto,
                    userName: user.userName
                }
        
                updateUser(tempUserStore.userID,userUpdate);
                amount.value="";
                alert("Recharge success!");
            }
        })
        
        
    }else{
        alert("Please enter the amount!")
    }
        
}


async function purchase(){
    (document.getElementById("home_content") as HTMLDivElement).style.display="none";
    (document.getElementById("WalletBalance_content") as HTMLDivElement).style.display="none";
    (document.getElementById("Walletrecharge_content") as HTMLInputElement).style.display="none";
    (document.getElementById("Purchase_content") as HTMLInputElement).style.display="block";
    (document.getElementById("Addproduct_content") as HTMLDivElement).style.display="none";
    (document.getElementById("Grocery_items_content") as HTMLDivElement).style.display="none";
    (document.getElementById("Card_content") as HTMLInputElement).style.display="none";
    (document.getElementById("View_order_history_content") as HTMLInputElement).style.display="none";
    (document.getElementById("SignOut") as HTMLInputElement).style.display="none";
    (document.getElementById("askcount_page") as HTMLInputElement).style.display="none";

    let purchase_items=document.getElementById("purchase_items") as HTMLDivElement;
    purchase_items.innerHTML="";

    let newBill:Bill={
        billID: undefined,
        userID: tempUserStore.userID,
        totalPrice: 0,
    }
    addbill(newBill);
    
    let grocerys=await fetchGrocery();

    grocerys.forEach(g=>{
        purchase_items.innerHTML+=`
                                <div id="card">
                                <img src="${g.itemPhoto}" alt="pic" width="60px" height="60px">
                                <h3>Name : ${g.itemName}</h3>
                                <h3>Price : ${g.price}</h3>
                                <h3> Quantity :${g.quantity}</h3>
                                <button onclick="itemaddtocard('${g.groceryID}')">Addto card</button>
                            </div>`
    })

}

var tempOrderList:Array<OrderDetails> =new Array<OrderDetails>; 
var tempIdstore:any;
async function itemaddtocard(selectid:any){
    (document.getElementById("home_content") as HTMLDivElement).style.display="none";
    (document.getElementById("WalletBalance_content") as HTMLDivElement).style.display="none";
    (document.getElementById("Walletrecharge_content") as HTMLInputElement).style.display="none";
    (document.getElementById("Purchase_content") as HTMLInputElement).style.display="none";
    (document.getElementById("Addproduct_content") as HTMLDivElement).style.display="none";
    (document.getElementById("Grocery_items_content") as HTMLDivElement).style.display="none";
    (document.getElementById("Card_content") as HTMLInputElement).style.display="none";
    (document.getElementById("View_order_history_content") as HTMLInputElement).style.display="none";
    (document.getElementById("SignOut") as HTMLInputElement).style.display="none";

    let askcount_page=document.getElementById("askcount_page") as HTMLDivElement;
    askcount_page.style.display="block";
        tempIdstore=selectid;
    
}



var tempBillId:any;
async function conformAddToCard(){

    let count=document.getElementById("count")as HTMLInputElement;
  
    let grocery=await fetchGrocery();
    
    let users=await fetchUser()
    let bills=await fetchBill();

    users.forEach(user=>{
        if(tempUserStore.userID==user.userID){
            tempUserStore=user;
        }
    })

    bills.forEach(bill=>{
        if(tempUserStore.userID == bill.userID){
                tempBillId=bill.billID;
        }
    })

    grocery.forEach(g=>{
            if(tempIdstore == g.groceryID){

                if(Number(g.quantity)>=Number(count.value)){
                    if(tempUserStore.walletBalance>=g.price){
                        let newcard:OrderDetails={
                            orderID: undefined,
                            orderDate: String(new Date),
                            emailID: tempUserStore.emailID,
                            itemName: g.itemName,
                            totalPrice: Number(count.value) * Number(g.price),
                            billID: tempBillId
                        }
                        tempOrderList.push(newcard);

                        let userUpdate:UserDetails={
                            userID: tempUserStore.userID,
                            emailID: tempUserStore.emailID,
                            password: tempUserStore.password,
                            walletBalance:Number(tempUserStore.walletBalance)-Number(newcard.totalPrice),
                            phoneNumber: tempUserStore.phoneNumber,
                            address: tempUserStore.address,
                            userPhoto:tempUserStore.userPhoto,
                            userName: tempUserStore.userName
                        };
                        updateUser(tempUserStore.userID,userUpdate);

                        let groceryUpdate:GroceryDetails={
                            groceryID: g.groceryID,
                            quantity:Number(g.quantity)-Number(count.value),
                            price: g.price,
                            purchaseDate: g.purchaseDate,
                            exparyDate: g.exparyDate,
                            itemPhoto: g.itemPhoto,
                            itemName: g.itemName
                        };

                        updateGrocery(g.groceryID,groceryUpdate);
                        (alert("Item added to card"));
                        count.value="";
                        purchase();
                    }else{
                        alert("Balance not available");
                        count.value="";
                        purchase();
                    }
                        
            }else{
                alert("count available");
                count.value="";
                purchase();
            }
        }
        
    });

}


function addproductpage(){
    (document.getElementById("home_content") as HTMLDivElement).style.display="none";
    (document.getElementById("WalletBalance_content") as HTMLDivElement).style.display="none";
    (document.getElementById("Walletrecharge_content") as HTMLInputElement).style.display="none";
    (document.getElementById("Purchase_content") as HTMLInputElement).style.display="none";
    (document.getElementById("Addproduct_content") as HTMLDivElement).style.display="block";
    (document.getElementById("Grocery_items_content") as HTMLDivElement).style.display="none";
    (document.getElementById("Card_content") as HTMLInputElement).style.display="none";
    (document.getElementById("View_order_history_content") as HTMLInputElement).style.display="none";
    (document.getElementById("SignOut") as HTMLInputElement).style.display="none";
    (document.getElementById("askcount_page") as HTMLInputElement).style.display="none";
}

async function grocerypage(){
    (document.getElementById("home_content") as HTMLDivElement).style.display="none";
    (document.getElementById("WalletBalance_content") as HTMLDivElement).style.display="none";
    (document.getElementById("Walletrecharge_content") as HTMLInputElement).style.display="none";
    (document.getElementById("Purchase_content") as HTMLInputElement).style.display="none";
    (document.getElementById("Addproduct_content") as HTMLDivElement).style.display="none";
    (document.getElementById("Grocery_items_content") as HTMLDivElement).style.display="block";
    (document.getElementById("Card_content") as HTMLInputElement).style.display="none";
    (document.getElementById("View_order_history_content") as HTMLInputElement).style.display="none";
    (document.getElementById("SignOut") as HTMLInputElement).style.display="none";
    (document.getElementById("askcount_page") as HTMLInputElement).style.display="none";

   let grocerytable=document.getElementById("grocerytable") as HTMLTableElement;

   grocerytable.innerHTML="";

   grocerytable.innerHTML=`<tr>
                                <td>${"ItemName"}</td>
                                <td>${"Quantity"}</td>
                                <td>${"Price"}</td>
                                <td>${"Purchase Date"}</td>
                                <td>${"Expary date"}</td>
                                <td>${"Picture"}</td>
                            </tr>`

    let grocerys=await fetchGrocery();

    grocerys.forEach(g=>{
        grocerytable.innerHTML+=`
                            <tr>
                                <td>${g.itemName}</td>
                                <td>${g.quantity}</td>
                                <td>${g.price}</td>
                                <td>${g.purchaseDate}</td>
                                <td>${g.exparyDate}</td>
                                <td><img src="${g.itemPhoto}" height=50px width=50px></td>
                                <td><button>edit</button>
                                <button>delete</button></td>
                            </tr>`
    });

}

function cardPage(){
    (document.getElementById("home_content") as HTMLDivElement).style.display="none";
    (document.getElementById("WalletBalance_content") as HTMLDivElement).style.display="none";
    (document.getElementById("Walletrecharge_content") as HTMLInputElement).style.display="none";
    (document.getElementById("Purchase_content") as HTMLInputElement).style.display="none";
    (document.getElementById("Addproduct_content") as HTMLDivElement).style.display="none";
    (document.getElementById("Grocery_items_content") as HTMLDivElement).style.display="none";
    (document.getElementById("Card_content") as HTMLInputElement).style.display="block";
    (document.getElementById("View_order_history_content") as HTMLInputElement).style.display="none";
    (document.getElementById("SignOut") as HTMLInputElement).style.display="none";
    (document.getElementById("askcount_page") as HTMLInputElement).style.display="none";

   let card_table= document.getElementById("card_table") as HTMLTableElement;
    if(tempOrderList.length >0){
        card_table.innerHTML="";

            card_table.innerHTML=`<tr>
                                            <td>${"OrderDate"}</td>
                                            <td>${"EmailID"}</td>
                                            <td>${"ItemName"}</td>
                                            <td>${"Total Price"}</td>
                                            </tr>`

                tempOrderList.forEach(g=>{
                    card_table.innerHTML+=`
                                        <tr>
                                            <td>${g.orderDate}</td>
                                            <td>${g.emailID}</td>
                                            <td>${g.itemName}</td>
                                            <td>${g.totalPrice}</td>
                                            </tr>`
                });
    }else{
        (document.getElementById("Card_content") as HTMLDivElement).innerHTML="<h1>No card items</h1>"
    }
   

}


async function conform_order()
{
    var totalCost:number=0;
    tempOrderList.forEach(order=>{
           totalCost+= Number(order.totalPrice);
    });

    let bills=await fetchBill();

    let tempBill:Bill=bills[bills.length-1];
    

    
            let billUpdate:Bill={
                billID: tempBill.billID,
                userID: tempBill.userID,
                totalPrice:totalCost
            }
            updateBill(tempBill.billID,billUpdate);

            tempOrderList.forEach(order=>{
                let newOrder:OrderDetails={
                    orderID: order.orderID,
                    billID:order.billID ,
                    orderDate: order.orderDate,
                    emailID: order.emailID,
                    itemName: order.itemName,
                    totalPrice: order.totalPrice
                }

                addOrder(newOrder);
            });

            alert("OrderConformed!")
}
 
    

    
    

    
async function orderHistorypage(){
    (document.getElementById("home_content") as HTMLDivElement).style.display="none";
    (document.getElementById("WalletBalance_content") as HTMLDivElement).style.display="none";
    (document.getElementById("Walletrecharge_content") as HTMLInputElement).style.display="none";
    (document.getElementById("Purchase_content") as HTMLInputElement).style.display="none";
    (document.getElementById("Addproduct_content") as HTMLDivElement).style.display="none";
    (document.getElementById("Grocery_items_content") as HTMLDivElement).style.display="none";
    (document.getElementById("Card_content") as HTMLInputElement).style.display="none";
    (document.getElementById("View_order_history_content") as HTMLInputElement).style.display="block";
    (document.getElementById("SignOut") as HTMLInputElement).style.display="none";
    (document.getElementById("askcount_page") as HTMLInputElement).style.display="none";

    let Bill_ID=document.getElementById("Bill_ID") as HTMLDivElement;
    let order_history_table=document.getElementById("order_history_table") as HTMLTableElement;

    
    order_history_table.innerHTML='';
    
    let bills=await fetchBill();
    let orders=await fetchOrder();

    for(let i=0;i<bills.length-1;i++){
        if(bills[i].userID==tempUserStore.userID){
            Bill_ID.innerHTML=`<h3>Name : ${tempUserStore.userName}</h3>
            <h3>Bill ID : ${bills[i].billID}</h3>
            <h3>TotalCost : ${bills[i].totalPrice}</h3>`
        }
        orders.forEach(order=>{
            if(order.billID == bills[i].billID){

                order_history_table.innerHTML+=`<tr>
                                                <td>${order.orderDate}</td>
                                                <td>${order.emailID}</td>
                                                <td>${order.itemName}</td>
                                                <td>${order.totalPrice}</td>
                                                </tr>`


            }
        })
    }
            
}

function signoutpage(){
    // (document.getElementById("home_content") as HTMLDivElement).style.display="none";
    // (document.getElementById("WalletBalance_content") as HTMLDivElement).style.display="none";
    // (document.getElementById("Walletrecharge_content") as HTMLInputElement).style.display="none";
    // (document.getElementById("Purchase_content") as HTMLInputElement).style.display="none";
    // (document.getElementById("Addproduct_content") as HTMLDivElement).style.display="none";
    // (document.getElementById("Grocery_items_content") as HTMLDivElement).style.display="none";
    // (document.getElementById("Card_content") as HTMLInputElement).style.display="none";
    // (document.getElementById("View_order_history_content") as HTMLInputElement).style.display="none";
    // (document.getElementById("SignOut") as HTMLInputElement).style.display="block";

   

    (document.getElementById("main_page") as HTMLDivElement).style.display="block";
    (document.getElementById("register_Page") as HTMLInputElement).style.display="none";
    (document.getElementById("login_page") as HTMLInputElement).style.display="none";
    
}



function addproduct(){
    let itemname=document.getElementById("itemname") as HTMLInputElement;
    let quantity=document.getElementById("quantity") as HTMLInputElement;
    let price=document.getElementById("price") as HTMLInputElement;
    let purchaseDate=document.getElementById("purchaseDate") as HTMLInputElement;
    let exparyDate=document.getElementById("exparyDate") as HTMLInputElement;
    let itemPhoto=document.getElementById("itemPhoto") as HTMLInputElement;
    

    try{
        const file:any= itemPhoto.files?.[0];
        const reader = new FileReader();
        reader.readAsDataURL(file);
        reader.onload = function (event) {
            var base64String =  event.target?.result as string;
            
            if(itemname.value!="" && quantity.value!="" && price.value!="" && purchaseDate.value!=""  && exparyDate.value!=""){
                    let newGrocery:GroceryDetails={
                        groceryID: undefined,
                        quantity:Number(quantity.value),
                        price: Number(price.value),
                        purchaseDate:purchaseDate.value,
                        exparyDate:exparyDate.value,
                        itemPhoto: [base64String],
                        itemName:itemname.value
                    }

                    addGrocery(newGrocery);
                    itemname.value!="";
                     quantity.value!="";
                      price.value!="" ; 
                      purchaseDate.value!="";
                    exparyDate.value!="";
                    addproduct();
                    alert("Item added success!");
                    
                }
            else{
                alert("Please fill all fields");
            }
        }
    }catch{
        alert("Please fill all fields")
    }
}
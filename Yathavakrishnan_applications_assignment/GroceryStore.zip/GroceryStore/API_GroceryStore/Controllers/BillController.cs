using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using API_GroceryStore.Data;
using Microsoft.AspNetCore.Mvc;

namespace API_GroceryStore.Controllers
{   
    [ApiController]
    [Route("api/[Controller]")]
    public class BillController:ControllerBase
    {
        private readonly ApplicationDBContext _dbContext;

        public BillController(ApplicationDBContext applicationDBContext){
            _dbContext=applicationDBContext;
        }

        [HttpGet]
        public IActionResult GetBill(){
            return Ok(_dbContext.bills.ToList());
        }

        [HttpGet("{billId}")]
        public IActionResult GetBill(int billId){
                var g=_dbContext.bills.FirstOrDefault(m=>m.BillID==billId);
                if(g==null){
                    return NotFound();
                }
                return Ok(g);
        }


        [HttpPost]
        public IActionResult PostBill([FromBody]Bill b){
            _dbContext.bills.Add(b);
            _dbContext.SaveChanges();
            return Ok();
        }

        [HttpPut("{billID}")]
        public IActionResult PostBill(int billID,[FromBody] Bill b){
            var billOld=_dbContext.bills.FirstOrDefault(m=>m.BillID == billID);

            if(billOld==null){
                return NotFound();
            }
            billOld.BillID=b.BillID;
            billOld.UserID=b.UserID;
            billOld.TotalPrice=b.TotalPrice;
           
            _dbContext.SaveChanges();
        
            return Ok();
        }


        [HttpDelete("{billID}")]
        public IActionResult DeleteBill(int billID){
            var g=_dbContext.bills.FirstOrDefault(m=>m.BillID==billID);

            if(g==null){
                return NotFound();
            }

            _dbContext.bills.Remove(g);
            _dbContext.SaveChanges();
            return Ok();
        }
    }
}